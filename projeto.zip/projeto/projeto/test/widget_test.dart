import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:projeto/pages/login_page.dart';

void main() {
  testWidgets('LoginPage shows email and password fields', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(MaterialApp(home: LoginPage()));

    expect(find.byType(TextField), findsNWidgets(2)); // email e senha
    expect(find.text('Entrar'), findsOneWidget);
    expect(find.text('Primeiro acesso? Cadastre-se'), findsOneWidget);
  });
}
