import 'package:flutter/material.dart';

class ClienteCard extends StatelessWidget {
  final String nome;
  final String status;

  ClienteCard({required this.nome, required this.status});

  Color _statusColor() {
    switch (status) {
      case '🔥':
        return Colors.red;
      case '🌡️':
        return Colors.orange;
      case '❄️':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: _statusColor(),
          child: Text(status),
        ),
        title: Text(nome),
      ),
    );
  }
}
