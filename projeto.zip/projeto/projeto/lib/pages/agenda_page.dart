import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AgendaPage extends StatefulWidget {
  @override
  _AgendaPageState createState() => _AgendaPageState();
}

class _AgendaPageState extends State<AgendaPage> {
  final primaryColor = Colors.blueAccent;

  // Lista de compromissos
  List<Map<String, dynamic>> compromissos = [
    {
      'titulo': 'Visita - Apartamento A101',
      'cliente': 'Carlos Souza',
      'data': DateTime.now().add(Duration(hours: 2)),
      'status': 'Confirmado'
    },
    {
      'titulo': 'Reunião de Negociação',
      'cliente': 'Ana Pereira',
      'data': DateTime.now().add(Duration(days: 1, hours: 1)),
      'status': 'Pendente'
    },
    {
      'titulo': 'Fechamento de contrato',
      'cliente': 'João Silva',
      'data': DateTime.now().add(Duration(days: 2)),
      'status': 'Confirmado'
    },
  ];

  String filtro = 'Hoje'; // Hoje, Semana, Mês

  List<Map<String, dynamic>> get filteredCompromissos {
    final now = DateTime.now();
    if (filtro == 'Hoje') {
      return compromissos
          .where((c) =>
              c['data'].year == now.year &&
              c['data'].month == now.month &&
              c['data'].day == now.day)
          .toList();
    } else if (filtro == 'Semana') {
      final startOfWeek = now.subtract(Duration(days: now.weekday - 1));
      final endOfWeek = startOfWeek.add(Duration(days: 6));
      return compromissos
          .where((c) =>
              c['data'].isAfter(startOfWeek.subtract(Duration(seconds: 1))) &&
              c['data'].isBefore(endOfWeek.add(Duration(days: 1))))
          .toList();
    } else {
      return compromissos
          .where((c) => c['data'].month == now.month && c['data'].year == now.year)
          .toList();
    }
  }

  Color statusColor(String status) {
    switch (status) {
      case 'Confirmado':
        return Colors.green;
      case 'Pendente':
        return Colors.orange;
      case 'Cancelado':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        elevation: 2,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Agenda'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Filtros de data
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: ['Hoje', 'Semana', 'Mês'].map((f) {
                final selected = filtro == f;
                return ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: selected ? primaryColor : Colors.grey[200],
                    foregroundColor: selected ? Colors.white : Colors.black87,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => setState(() {
                    filtro = f;
                  }),
                  child: Text(f),
                );
              }).toList(),
            ),
            SizedBox(height: 16),

            // Lista de compromissos
            Expanded(
              child: filteredCompromissos.isEmpty
                  ? Center(child: Text('Nenhum compromisso encontrado'))
                  : ListView.builder(
                      itemCount: filteredCompromissos.length,
                      itemBuilder: (context, index) {
                        final c = filteredCompromissos[index];
                        return Card(
                          margin: EdgeInsets.symmetric(vertical: 8),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          elevation: 4,
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundColor: statusColor(c['status']),
                              child: Icon(Icons.event, color: Colors.white),
                            ),
                            title: Text(c['titulo'],
                                style: TextStyle(
                                    fontWeight: FontWeight.bold)),
                            subtitle: Text(
                                '${c['cliente']} • ${DateFormat('dd/MM/yyyy HH:mm').format(c['data'])}'),
                            trailing: Text(c['status'],
                                style: TextStyle(
                                    color: statusColor(c['status']),
                                    fontWeight: FontWeight.bold)),
                            onTap: () {
                              _showDetalhesCompromisso(c);
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDetalhesCompromisso(Map<String, dynamic> compromisso) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                height: 4,
                width: 50,
                color: Colors.grey[300],
              ),
            ),
            SizedBox(height: 16),
            Text(compromisso['titulo'],
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Cliente: ${compromisso['cliente']}'),
            SizedBox(height: 8),
            Text('Data: ${DateFormat('dd/MM/yyyy HH:mm').format(compromisso['data'])}'),
            SizedBox(height: 8),
            Text('Status: ${compromisso['status']}'),
            SizedBox(height: 20),
            Center(
              child: ElevatedButton.icon(
                icon: Icon(Icons.edit),
                label: Text('Editar Compromisso'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
