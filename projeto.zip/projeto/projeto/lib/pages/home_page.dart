import 'package:flutter/material.dart';
import 'clientes_page.dart';
import 'funil_page.dart';
import 'insights_page.dart';
import 'relatorios_page.dart';
import 'agenda_page.dart';
import 'package:fl_chart/fl_chart.dart';

class HomePage extends StatelessWidget {
  final String userName = "João Silva";
  final Color primaryColor = Colors.blueAccent;

  // KPIs
  final List<Map<String, dynamic>> kpis = [
    {'titulo': 'Melhor horário', 'valor': '10h - 12h', 'icone': Icons.access_time},
    {'titulo': 'Clientes inativos', 'valor': 3, 'icone': Icons.person_off},
    {'titulo': 'Novos clientes', 'valor': 2, 'icone': Icons.person_add},
    {'titulo': 'Imóveis disponíveis', 'valor': 5, 'icone': Icons.home},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: primaryColor,
        elevation: 2,
        title: Row(
          children: [
            CircleAvatar(
              radius: 20,
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: primaryColor),
            ),
            SizedBox(width: 10),
            Text(userName, style: TextStyle(fontSize: 18)),
            Spacer(),
            GestureDetector(
              onTap: () {
                showModalBottomSheet(
                  context: context,
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
                  builder: (_) => Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        ListTile(
                          leading: Icon(Icons.person),
                          title: Text('Gerenciar Perfil'),
                          onTap: () {},
                        ),
                        ListTile(
                          leading: Icon(Icons.logout),
                          title: Text('Sair'),
                          onTap: () {
                            Navigator.pop(context);
                            Navigator.pushReplacementNamed(context, '/login');
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
              child: Icon(Icons.menu, size: 28),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // === Gráfico de Meta (Pizza) ===
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      'Meta de Vendas',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                      ),
                    ),
                    SizedBox(height: 16),
                    SizedBox(
                      height: 200,
                      child: PieChart(
                        PieChartData(
                          sections: [
                            PieChartSectionData(
                                value: 75,
                                color: primaryColor,
                                title: '75%',
                                radius: 60,
                                titleStyle: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white)),
                            PieChartSectionData(
                                value: 25,
                                color: Colors.grey[300]!,
                                title: '',
                                radius: 60),
                          ],
                          centerSpaceRadius: 40,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 20),

            // === Acesso rápido ===
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _quickAccessCard(context, Icons.people, 'Clientes', ClientesPage()),
                _quickAccessCard(context, Icons.bar_chart, 'Insights', InsightsPage()),
                _quickAccessCard(context, Icons.home, 'Funil', FunilPage()),
                _quickAccessCard(context, Icons.insert_chart, 'Relatórios', RelatoriosPage()),
                _quickAccessCard(context, Icons.calendar_today, 'Agenda', AgendaPage()),
              ],
            ),
            SizedBox(height: 24),

            // === KPIs principais ===
            GridView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: kpis.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: MediaQuery.of(context).size.width > 600 ? 4 : 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                childAspectRatio: 1.2,
              ),
              itemBuilder: (context, index) {
                final kpi = kpis[index];
                return Card(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 4,
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(kpi['icone'], color: primaryColor, size: 32),
                        SizedBox(height: 10),
                        Text(kpi['titulo'],
                            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            textAlign: TextAlign.center),
                        SizedBox(height: 6),
                        Text('${kpi['valor']}', style: TextStyle(fontSize: 14, color: Colors.black54)),
                      ],
                    ),
                  ),
                );
              },
            ),
            SizedBox(height: 24),

            // === Gráfico de Vendas Detalhado (BarChart) ===
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      'Vendas nos últimos meses',
                      style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 18, color: primaryColor),
                    ),
                    SizedBox(height: 16),
                    SizedBox(
                      height: 200,
                      child: BarChart(
                        BarChartData(
                          alignment: BarChartAlignment.spaceAround,
                          maxY: 10,
                          titlesData: FlTitlesData(
                            leftTitles: AxisTitles(
                              sideTitles: SideTitles(showTitles: true),
                            ),
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: (value, meta) {
                                  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May'];
                                  return Text(months[value.toInt() % 5]);
                                },
                              ),
                            ),
                          ),
                          borderData: FlBorderData(show: false),
                          barGroups: [
                            BarChartGroupData(x: 0, barRods: [BarChartRodData(toY: 4, color: primaryColor, width: 18)]),
                            BarChartGroupData(x: 1, barRods: [BarChartRodData(toY: 6, color: primaryColor, width: 18)]),
                            BarChartGroupData(x: 2, barRods: [BarChartRodData(toY: 5, color: primaryColor, width: 18)]),
                            BarChartGroupData(x: 3, barRods: [BarChartRodData(toY: 7, color: primaryColor, width: 18)]),
                            BarChartGroupData(x: 4, barRods: [BarChartRodData(toY: 3, color: primaryColor, width: 18)]),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _quickAccessCard(BuildContext context, IconData icon, String label, Widget page) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => page));
        },
        child: Card(
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 36, color: primaryColor),
                SizedBox(height: 10),
                Text(
                  label,
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black54),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
