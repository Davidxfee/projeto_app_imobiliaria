import 'package:flutter/material.dart';

class FunilPage extends StatefulWidget {
  @override
  _FunilPageState createState() => _FunilPageState();
}

class _FunilPageState extends State<FunilPage> {
  final primaryColor = Colors.blueAccent;

  final List<String> fases = ['Prospect', 'Negociação', 'Fechado'];

  Map<String, List<Map<String, dynamic>>> clientesPorFase = {
    'Prospect': [
      {
        'nome': 'Carlos Souza',
        'imovel': 'Apartamento A101',
        'valor': 2500.0,
        'progresso': 20
      },
      {
        'nome': 'Mariana Costa',
        'imovel': 'Casa D101',
        'valor': 2200.0,
        'progresso': 30
      },
    ],
    'Negociação': [
      {
        'nome': 'Ana Pereira',
        'imovel': 'Casa B203',
        'valor': 3000.0,
        'progresso': 60
      },
      {
        'nome': 'Cliente 5',
        'imovel': 'Apartamento C302',
        'valor': 2700.0,
        'progresso': 50
      },
    ],
    'Fechado': [
      {
        'nome': 'João Silva',
        'imovel': 'Apartamento C305',
        'valor': 1800.0,
        'progresso': 100
      },
    ],
  };

  String? dragOverFase; // Guarda a coluna que está recebendo o item

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    int crossAxisCount = 1;
    if (screenWidth > 1200) {
      crossAxisCount = 3;
    } else if (screenWidth > 800) {
      crossAxisCount = 2;
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        elevation: 2,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Funil de Vendas'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 0.75,
          ),
          itemCount: fases.length,
          itemBuilder: (context, index) {
            final fase = fases[index];
            final clientes = clientesPorFase[fase]!;

            return AnimatedContainer(
              duration: Duration(milliseconds: 300),
              decoration: BoxDecoration(
                color:
                    dragOverFase == fase ? Colors.blue[50] : Colors.grey[100],
                borderRadius: BorderRadius.circular(12),
              ),
              padding: EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(fase,
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: primaryColor)),
                  SizedBox(height: 12),
                  Expanded(
                    child: DragTarget<Map<String, dynamic>>(
                      onWillAccept: (data) {
                        setState(() => dragOverFase = fase);
                        return true;
                      },
                      onLeave: (data) {
                        setState(() => dragOverFase = null);
                      },
                      onAccept: (data) {
                        setState(() {
                          clientesPorFase[data['fromFase']]!
                              .remove(data['cliente']);
                          clientesPorFase[fase]!.add(data['cliente']);
                          dragOverFase = null;
                        });
                      },
                      builder: (context, candidateData, rejectedData) {
                        return ListView(
                          children: clientes
                              .map((cliente) =>
                                  _draggableClienteCard(cliente, fase))
                              .toList(),
                        );
                      },
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _draggableClienteCard(Map<String, dynamic> cliente, String fase) {
    return LongPressDraggable<Map<String, dynamic>>(
      data: {'cliente': cliente, 'fromFase': fase},
      feedback: Material(
        color: Colors.transparent,
        child: Transform.scale(
          scale: 1.05,
          child: _clienteCard(cliente, dragging: true),
        ),
      ),
      childWhenDragging: Opacity(
        opacity: 0.5,
        child: _clienteCard(cliente),
      ),
      child: _clienteCard(cliente),
    );
  }

  Widget _clienteCard(Map<String, dynamic> cliente, {bool dragging = false}) {
    Color cardColor;
    if (cliente['progresso'] >= 80) {
      cardColor = Colors.green[100]!;
    } else if (cliente['progresso'] >= 50) {
      cardColor = Colors.yellow[100]!;
    } else {
      cardColor = Colors.blue[50]!;
    }

    return GestureDetector(
      onTap: () => _showClienteDetalhe(cliente),
      child: AnimatedContainer(
        duration: Duration(milliseconds: 300),
        margin: EdgeInsets.symmetric(vertical: 8),
        child: Card(
          elevation: dragging ? 8 : 3,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          color: cardColor,
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(cliente['nome'],
                    style:
                        TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                SizedBox(height: 6),
                Text(cliente['imovel'], style: TextStyle(fontSize: 14)),
                SizedBox(height: 8),
                LinearProgressIndicator(
                  value: cliente['progresso'] / 100,
                  backgroundColor: Colors.grey[300],
                  color: primaryColor,
                  minHeight: 6,
                ),
                SizedBox(height: 4),
                Text('${cliente['progresso']}% concluído',
                    style: TextStyle(fontSize: 12, color: Colors.grey[700])),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showClienteDetalhe(Map<String, dynamic> cliente) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                  child:
                      Container(height: 4, width: 50, color: Colors.grey[300])),
              SizedBox(height: 16),
              Text(cliente['nome'],
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              _infoRow('Imóvel:', cliente['imovel']),
              _infoRow('Valor:', 'R\$ ${cliente['valor']}'),
              _infoRow('Progresso:', '${cliente['progresso']}%'),
              SizedBox(height: 20),
              Center(
                child: ElevatedButton.icon(
                  icon: Icon(Icons.edit),
                  label: Text('Editar Cliente'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                  onPressed: () => Navigator.pop(context),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Expanded(
              flex: 3,
              child:
                  Text(label, style: TextStyle(fontWeight: FontWeight.bold))),
          Expanded(flex: 5, child: Text(value)),
        ],
      ),
    );
  }
}
