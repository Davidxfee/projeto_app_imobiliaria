import 'package:flutter/material.dart';

class ClientesPage extends StatelessWidget {
  // Dados base de clientes
  final List<Map<String, dynamic>> clientes = [
    {
      'nome': 'Carlos Souza',
      'inicio': '01/08/2025',
      'fim': '01/08/2026',
      'parcelas': 12,
      'valor': 2500.0,
      'telefone': '99999-0001',
      'email': 'carlos@email.com',
      'imovel': 'Apartamento A101'
    },
    {
      'nome': 'Ana Pereira',
      'inicio': '15/07/2025',
      'fim': '15/07/2026',
      'parcelas': 12,
      'valor': 3000.0,
      'telefone': '99999-0002',
      'email': 'ana@email.com',
      'imovel': 'Casa B203'
    },
    {
      'nome': 'João Silva',
      'inicio': '10/06/2025',
      'fim': '10/06/2026',
      'parcelas': 12,
      'valor': 1800.0,
      'telefone': '99999-0003',
      'email': 'joao@email.com',
      'imovel': 'Apartamento C305'
    },
    {
      'nome': 'Mariana Costa',
      'inicio': '05/05/2025',
      'fim': '05/05/2026',
      'parcelas': 12,
      'valor': 2200.0,
      'telefone': '99999-0004',
      'email': 'mariana@email.com',
      'imovel': 'Casa D101'
    },
    {
      'nome': 'Rafael Lima',
      'inicio': '20/04/2025',
      'fim': '20/04/2026',
      'parcelas': 12,
      'valor': 2700.0,
      'telefone': '99999-0005',
      'email': 'rafael@email.com',
      'imovel': 'Apartamento E402'
    },
  ];

  @override
  Widget build(BuildContext context) {
    final primaryColor = Colors.blueAccent;

    return Scaffold(
      appBar: AppBar(
        title: Text('Clientes'),
        backgroundColor: primaryColor,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: clientes.length,
        itemBuilder: (context, index) {
          final cliente = clientes[index];
          return Card(
            elevation: 3,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
            margin: EdgeInsets.symmetric(vertical: 8),
            child: ListTile(
              contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: CircleAvatar(
                backgroundColor: primaryColor,
                child: Icon(Icons.person, color: Colors.white),
              ),
              title: Text(cliente['nome'],
                  style: TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(cliente['imovel']),
              trailing: Icon(Icons.arrow_forward_ios, size: 18),
              onTap: () {
                // Abrir detalhe do cliente
                showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(16)),
                  ),
                  builder: (_) => Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Center(
                            child: Container(
                              height: 4,
                              width: 50,
                              color: Colors.grey[300],
                            ),
                          ),
                          SizedBox(height: 16),
                          Text(cliente['nome'],
                              style: TextStyle(
                                  fontSize: 22, fontWeight: FontWeight.bold)),
                          SizedBox(height: 10),
                          _infoRow('Imóvel:', cliente['imovel']),
                          _infoRow('Data Início:', cliente['inicio']),
                          _infoRow('Data Fim:', cliente['fim']),
                          _infoRow('Parcelas:', cliente['parcelas'].toString()),
                          _infoRow('Valor:', 'R\$ ${cliente['valor']}'),
                          _infoRow('Telefone:', cliente['telefone']),
                          _infoRow('E-mail:', cliente['email']),
                          SizedBox(height: 20),
                          Center(
                            child: ElevatedButton.icon(
                              icon: Icon(Icons.edit),
                              label: Text('Editar Cliente'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryColor,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 24, vertical: 12),
                              ),
                              onPressed: () {
                                // Aqui você pode adicionar a tela de edição
                                Navigator.pop(context);
                              },
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Expanded(
              flex: 3,
              child: Text(label,
                  style: TextStyle(fontWeight: FontWeight.bold))),
          Expanded(flex: 5, child: Text(value)),
        ],
      ),
    );
  }
}
