import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class RelatoriosPage extends StatelessWidget {
  final List<Map<String, dynamic>> relatorios = [
    {
      'titulo': 'Relatório de Vendas',
      'descricao': 'Total de clientes atendidos',
      'valor': 15,
      'icone': Icons.shopping_cart,
      'cor': Colors.blueAccent,
      'dados': [3, 5, 7, 6, 8, 5, 9]
    },
    {
      'titulo': 'Relatório de Prospecção',
      'descricao': 'Novos clientes adquiridos',
      'valor': 5,
      'icone': Icons.person_add,
      'cor': Colors.orangeAccent,
      'dados': [1, 2, 2, 3, 2, 4, 3]
    },
    {
      'titulo': 'Relatório de Conversão',
      'descricao': 'Taxa de conversão (%)',
      'valor': 60,
      'icone': Icons.show_chart,
      'cor': Colors.green,
      'dados': [50, 55, 60, 58, 62, 59, 60]
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text('Relatórios'),
        backgroundColor: Colors.blueAccent,
        elevation: 2,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView.builder(
          itemCount: relatorios.length,
          itemBuilder: (context, index) {
            final rel = relatorios[index];
            return Card(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              elevation: 4,
              margin: const EdgeInsets.symmetric(vertical: 8),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        radius: 28,
                        backgroundColor: rel['cor'].withOpacity(0.2),
                        child: Icon(
                          rel['icone'],
                          color: rel['cor'],
                          size: 28,
                        ),
                      ),
                      title: Text(
                        rel['titulo'],
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                      subtitle: Text(
                        rel['descricao'],
                        style: TextStyle(color: Colors.black54),
                      ),
                      trailing: Container(
                        padding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: rel['cor'].withOpacity(0.2),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          '${rel['valor']}',
                          style: TextStyle(
                              fontWeight: FontWeight.bold, color: rel['cor']),
                        ),
                      ),
                    ),
                    SizedBox(height: 12),
                    SizedBox(
                      height: 80,
                      child: LineChart(
                        LineChartData(
                          gridData: FlGridData(show: false),
                          titlesData: FlTitlesData(show: false),
                          borderData: FlBorderData(show: false),
                          lineBarsData: [
                            LineChartBarData(
                              spots: List.generate(
                                  rel['dados'].length,
                                  (i) => FlSpot(
                                      i.toDouble(),
                                      (rel['dados'][i] as num)
                                          .toDouble())),
                              isCurved: true,
                              gradient: LinearGradient(
                                  colors: [rel['cor'], rel['cor'].withOpacity(0.5)]),
                              barWidth: 3,
                              dotData: FlDotData(show: false),
                              belowBarData: BarAreaData(
                                show: true,
                                gradient: LinearGradient(
                                    colors: [
                                      rel['cor'].withOpacity(0.2),
                                      Colors.transparent
                                    ],
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
