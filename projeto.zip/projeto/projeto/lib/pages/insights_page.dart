import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

class InsightsPage extends StatelessWidget {
  final primaryColor = Colors.blueAccent;

  final List<Map<String, dynamic>> kpis = [
    {'titulo': 'Melhor horário', 'valor': '10h - 12h', 'icone': Icons.access_time},
    {'titulo': 'Clientes inativos', 'valor': 3, 'icone': Icons.person_off},
    {'titulo': 'Novos clientes', 'valor': 2, 'icone': Icons.person_add},
    {'titulo': 'Imóveis disponíveis', 'valor': 5, 'icone': Icons.home},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        backgroundColor: primaryColor,
        title: Text('Insights'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // KPIs
            GridView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: kpis.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 16,
                  crossAxisSpacing: 16,
                  childAspectRatio: 1.2),
              itemBuilder: (context, index) {
                final kpi = kpis[index];
                return Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(kpi['icone'], color: primaryColor, size: 32),
                        SizedBox(height: 10),
                        Text(
                          kpi['titulo'],
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16),
                          textAlign: TextAlign.center,
                        ),
                        SizedBox(height: 6),
                        Text('${kpi['valor']}',
                            style: TextStyle(
                                fontSize: 14, color: Colors.black54)),
                      ],
                    ),
                  ),
                );
              },
            ),
            SizedBox(height: 24),

            // Vendas últimos meses
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text('Vendas nos últimos meses',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: primaryColor)),
                    SizedBox(height: 16),
                    SizedBox(
                      height: 200,
                      child: BarChart(
                        BarChartData(
                          alignment: BarChartAlignment.spaceAround,
                          maxY: 10,
                          titlesData: FlTitlesData(
                            leftTitles: AxisTitles(
                                sideTitles: SideTitles(showTitles: true)),
                            bottomTitles: AxisTitles(
                              sideTitles: SideTitles(
                                showTitles: true,
                                getTitlesWidget: (value, meta) {
                                  const months = [
                                    'Jan',
                                    'Feb',
                                    'Mar',
                                    'Apr',
                                    'May'
                                  ];
                                  return Text(months[value.toInt() % 5]);
                                },
                              ),
                            ),
                          ),
                          borderData: FlBorderData(show: false),
                          barGroups: [
                            BarChartGroupData(
                                x: 0,
                                barRods: [BarChartRodData(toY: 4, color: primaryColor, width: 18)]),
                            BarChartGroupData(
                                x: 1,
                                barRods: [BarChartRodData(toY: 6, color: primaryColor, width: 18)]),
                            BarChartGroupData(
                                x: 2,
                                barRods: [BarChartRodData(toY: 5, color: primaryColor, width: 18)]),
                            BarChartGroupData(
                                x: 3,
                                barRods: [BarChartRodData(toY: 7, color: primaryColor, width: 18)]),
                            BarChartGroupData(
                                x: 4,
                                barRods: [BarChartRodData(toY: 3, color: primaryColor, width: 18)]),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 24),

            // Funil de vendas
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text('Funil de Vendas',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: primaryColor)),
                    SizedBox(height: 16),
                    SizedBox(
                      height: 200,
                      child: PieChart(
                        PieChartData(
                          sections: [
                            PieChartSectionData(
                                value: 3,
                                color: Colors.orangeAccent,
                                title: 'Prospect',
                                radius: 60,
                                titleStyle:
                                    TextStyle(fontSize: 14, color: Colors.white)),
                            PieChartSectionData(
                                value: 2,
                                color: Colors.lightBlueAccent,
                                title: 'Negociação',
                                radius: 60,
                                titleStyle:
                                    TextStyle(fontSize: 14, color: Colors.white)),
                            PieChartSectionData(
                                value: 1,
                                color: Colors.green,
                                title: 'Fechado',
                                radius: 60,
                                titleStyle:
                                    TextStyle(fontSize: 14, color: Colors.white)),
                          ],
                          centerSpaceRadius: 30,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 24),

            // Receita por imóvel
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text('Receita por Imóvel',
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: primaryColor)),
                    SizedBox(height: 16),
                    SizedBox(
                      height: 200,
                      child: LineChart(
                        LineChartData(
                          gridData: FlGridData(show: true),
                          borderData: FlBorderData(show: true),
                          titlesData: FlTitlesData(show: true),
                          lineBarsData: [
                            LineChartBarData(
                              spots: [
                                FlSpot(0, 2),
                                FlSpot(1, 4),
                                FlSpot(2, 3),
                                FlSpot(3, 5),
                                FlSpot(4, 4),
                              ],
                              isCurved: true,
                              barWidth: 3,
                              gradient: LinearGradient(
                                colors: [
                                  primaryColor,
                                  primaryColor.withOpacity(0.7)
                                ],
                              ),
                              dotData: FlDotData(show: true),
                            )
                          ],
                          lineTouchData: LineTouchData(
                            enabled: true,
                            handleBuiltInTouches: true,
                            touchTooltipData: LineTouchTooltipData(
                              getTooltipItems: (spots) {
                                return spots.map((spot) {
                                  return LineTooltipItem(
                                    'R\$ ${spot.y}',
                                    TextStyle(color: Colors.white),
                                  );
                                }).toList();
                              },
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
